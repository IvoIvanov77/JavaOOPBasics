package exam_preparetion.nfs.models.Garage;

import exam_preparetion.nfs.models.Cars.Car;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by ivaylo on 11/5/2017.
 */
public class Garage {

    private Collection<Car> parkedCars;

    public Garage() {
        this.parkedCars = new ArrayList<>();
    }
}
