package exam_preparetion.nfs.models.Races;

/**
 * Created by ivaylo on 11/5/2017.
 */
public class CasualRace extends Race {
    public CasualRace(int length, String route, int prizePool) {
        super(length, route, prizePool);
    }
}
