package exam_preparetion.nfs.models.Cars;

import java.util.Collection;

/**
 * Created by ivaylo on 11/5/2017.
 */
public abstract class Car {

//    a brand (string), a model (string), an yearOfProduction (int),
// horsepower (int), acceleration (int), suspension (int), and durability (int).

    private String brand;
    private String model;
    private Integer yearOfProduction;
    private Integer horsepower;
    private Integer acceleration;
    private Integer suspension;
    private Integer durability;

    public Car(String brand, String model, Integer yearOfProduction,
               Integer horsepower, Integer acceleration, Integer suspension,
               Integer durability) {
        this.setBrand(brand);
        this.setModel(model);
        this.setYearOfProduction(yearOfProduction);
        this.setHorsepower(horsepower);
        this.setAcceleration(acceleration);
        this.setSuspension(suspension);
        this.setDurability(durability);
    }

    public String getBrand() {
        return brand;
    }

    private void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    private void setModel(String model) {
        this.model = model;
    }

    public Integer getYearOfProduction() {
        return yearOfProduction;
    }

    private void setYearOfProduction(Integer yearOfProduction) {
        this.yearOfProduction = yearOfProduction;
    }

    public Integer getHorsepower() {
        return horsepower;
    }

    protected void setHorsepower(Integer horsepower) {
        this.horsepower = horsepower;
    }

    public Integer getAcceleration() {
        return acceleration;
    }

    private void setAcceleration(Integer acceleration) {
        this.acceleration = acceleration;
    }

    public Integer getSuspension() {
        return suspension;
    }

    protected void setSuspension(Integer suspension) {
        this.suspension = suspension;
    }

    public Integer getDurability() {
        return durability;
    }

    private void setDurability(Integer durability) {
        this.durability = durability;
    }

    @Override
    public String toString() {
        return String.format(
                "%s %s %d\n" +
                "%d HP, 100 m/h in %d s\n" +
                        "%d Suspension force, %d Durability\n",
                this.getBrand(), this.getModel(), this.getYearOfProduction(),
                this.getHorsepower(), this.getAcceleration(),
                this.getSuspension(), this.getDurability()
        );
    }



    //    “{brand} {model} {yearOfProduction}
//    {horsepower} HP, 100 m/h in {acceleration} s
//    {suspension} Suspension force, {durability} Durability”
//    If the car is a PerformanceCar, you must print “Add-ons: {add-ons}”, on the
//    last line – each add-on separated by a comma and a space “, “. In case there are
//    NO add-ons, print “None”.
//    If the car is a ShowCar, you must print “{stars} *”, on the last line.

}
