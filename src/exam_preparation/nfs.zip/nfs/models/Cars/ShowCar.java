package exam_preparetion.nfs.models.Cars;

import exam_preparetion.nfs.models.Cars.Car;

/**
 * Created by ivaylo on 11/5/2017.
 */
public class ShowCar extends Car {

    private Integer stars;

    public ShowCar(String brand, String model, Integer yearOfProduction, Integer horsepower,
                   Integer acceleration, Integer suspension, Integer durability) {
        super(brand, model, yearOfProduction, horsepower, acceleration, suspension, durability);
        this.stars = 0;
    }

    @Override
    public String toString() {
        return super.toString() + "\n" + this.stars + " *";
    }
}
